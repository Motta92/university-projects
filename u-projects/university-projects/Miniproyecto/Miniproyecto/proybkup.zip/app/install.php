<?php 
/* En este archivo se encuentras todos los elementos a ejecutar
 * para la creacion de las tablas y respectivas relaciones
 * de la base de datos.
 */

/* Tabla usuarios */

// SQL: create table usuarios (id int primary key, ...);

// This should be an awesome script.

/* Tabla obras */

// Something should be here

 ?>