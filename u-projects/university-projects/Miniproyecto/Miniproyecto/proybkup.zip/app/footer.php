    <footer class="container">
      <p class="text-muted">Galería de Arte © Carlos Motta, Santiago Quintero, Edgar Amezquita</p>
    </footer>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo $baseUrl; ?>/js/bootstrap.min.js"></script>
  </body>
</html>