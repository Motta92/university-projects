<?php 
define('SQ_PHP_SECURITY', true);
require 'app-config.php';
require 'functions.php';


unset($_SESSION['user_id']);
unset($_SESSION['user_level']);
redirect_to("../index.php");

?>