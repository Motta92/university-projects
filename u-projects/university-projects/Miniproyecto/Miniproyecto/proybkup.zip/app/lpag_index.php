<?php 
define('SQ_PHP_SECURITY', true);
require 'app-config.php';
require 'functions.php';



?>