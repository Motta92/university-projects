<?php 
define('SQ_PHP_SECURITY', true);
require 'app-config.php';
require 'functions.php';

$idimg = $_GET['idimagen'];

$db_con = mysqli_connect($db_host,$db_user, $db_pass, $db_name);

if(mysqli_connect_errno()){
$not_connected = "database connection failed: " .
mysqli_connect_error() .
" (" . mysqli_connect_errno() . ")";
// Error handling
fail($not_connected);
}
$query = "SELECT direccion ";
$query .= " FROM imagen";
$query .= " WHERE idimagen = {$idimg}";
$result = mysqli_query($db_con, $query);
$line = mysqli_fetch_assoc($result);
$filename="../img/".$line['direccion'];
if (file_exists($filename)) {
    unlink($filename);
    echo 'File '.$filename.' has been deleted';
  } else {
    echo 'Could not delete '.$filename.', file does not exist';
  }
$query = "DELETE ";
$query .= " FROM imagen";
$query .= " WHERE idimagen = {$idimg}";
$result = mysqli_query($db_con, $query);

echo "Imagen eliminada";
mysqli_close($db_con);
redirect_to("../perfil.php?idusuario=".$gb_user_id);
?>