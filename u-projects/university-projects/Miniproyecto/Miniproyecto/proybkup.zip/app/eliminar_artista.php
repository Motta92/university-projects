<?php 
define('SQ_PHP_SECURITY', true);
require 'app-config.php';
require 'functions.php';

$idartist = $_GET['idartist'];
echo $idartist;

$con = mysqli_connect($db_host,$db_user, $db_pass, $db_name);

if(mysqli_connect_errno()){
$not_connected = "database connection failed: " .
mysqli_connect_error() .
" (" . mysqli_connect_errno() . ")";
// Error handling
fail($not_connected);
}

// Query para seleccionar las ultimas imagenes subidas
$query = "DELETE ";
$query .= " FROM usuario";
$query .= " WHERE id = {$idartist}";

$result = mysqli_query($con, $query);

echo "Usuario eliminado";
redirect_to("../artistas.php");

?>