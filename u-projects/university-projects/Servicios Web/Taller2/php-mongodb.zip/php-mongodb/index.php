<?php
/* Reporta todos los errores de php*/
error_reporting(E_ALL);
/* Le asigna un valor a una opción de configuración */
ini_set('display_errors', 1);

/* Carga la clase que tiene la configuracion general */
require 'app.php';
try {
    /* isset revisa si una variable tiene asignado algun valor, incluso una cadena vacia */
	$currentPage = (isset($_GET['page'])) ? (int) $_GET['page'] : 1; //current page number
        
        /*db es un objeto creado en app.php. Posts es el nombre de la coleccion*/
         $data = $db->get($currentPage,'posts');
       
         /* layout es un objeto creado en app.php. Estos datos son utiles en la vista */
        $layout->view('index',array(
            'currentPage'  => $data[0],
            'totalPages'   => $data[1],
            'cursor'       => $data[2],
            'name'		=>	'Duy Thien'

    ));

	
} catch (Exception $e) {
	 echo 'Caught exception: ',  $e->getMessage(), "\n";
}
