<?php
define('URL', 'http://localhost/php-mongodb/');
define('UserAuth', 'web');
define('PasswordAuth', 'web');

$config = array(
	'username' => 'web',
	'password' => 'web',
	'dbname'   => 'blog',
	'connection_string'=> sprintf('mongodb://%s:%d/%s','127.0.0.1','27017','blog')
);
