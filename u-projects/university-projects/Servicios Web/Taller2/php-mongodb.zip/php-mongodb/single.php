<?php

require 'app.php';

// Trae el documento dado el id
$post = $db->getById($_GET['id'],'posts');
if ($post == FALSE) {	
	/* Si no lo encuentra devuelve al usuario a la logica del index.php */
	header('Location: index.php');
	
} else {
	/* Dibuja la vista asociada a un solo post mandandole el post encontrado */
	$layout->view('single', array(
		'article' => $post
	));
}
