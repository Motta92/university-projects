<?php

require 'app.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' ) {

	$id = $_POST['article_id'];
	/* Se crea un arreglo con los datos luego esto se envia a la bd para actualizar el documento */
	$comment = array(
              	'name' => $_POST['fName'], 
                'email' => $_POST['fEmail'],
                'comment' => $_POST['fComment'],
                'posted_at' => new MongoDate()
	);
	/* posts es el nombre de la coleccion en la que se quieren insertar las cosas */
	$status = $db->commentId($id,'posts',$comment);
	/* Se vuelve a cargar la pagina de single.php. Al volver a hacer todo el proceso
	se debe ver el nuevo comentario */
	if ($status == TRUE) {
		header('Location: single.php?id='.$id);
	}
		

}
